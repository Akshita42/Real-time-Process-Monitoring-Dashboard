document.addEventListener("DOMContentLoaded", function () {
    initCharts();
    fetchStats();
    setInterval(fetchStats, 2000);
});

let cpuChart, memoryChart;

// Initialize Charts
function initCharts() {
    let ctxCpu = document.getElementById('cpuChart').getContext('2d');
    let ctxMemory = document.getElementById('memoryChart').getContext('2d');

    cpuChart = new Chart(ctxCpu, {
        type: 'line',
        data: { labels: [], datasets: [{ label: 'CPU Usage (%)', data: [], borderColor: 'blue', fill: false }] },
        options: { scales: { y: { beginAtZero: true, max: 100 } } }
    });

    memoryChart = new Chart(ctxMemory, {
        type: 'line',
        data: { labels: [], datasets: [{ label: 'Memory Usage (%)', data: [], borderColor: 'red', fill: false }] },
        options: { scales: { y: { beginAtZero: true, max: 100 } } }
    });
}

// Fetch System Stats
function fetchStats() {
    fetch('/stats')
        .then(response => response.json())
        .then(data => {
            document.getElementById('cpu-usage').innerText = data.cpu_usage + "%";
            document.getElementById('memory-usage').innerText = data.memory_usage + "%";
            document.getElementById('total-processes').innerText = data.processes.length;

            updateChart(cpuChart, data.cpu_usage);
            updateChart(memoryChart, data.memory_usage);
            updateProcessTable(data.processes);
        })
        .catch(error => console.error("Error fetching stats:", error));
}

// Update Chart Data
function updateChart(chart, value) {
    chart.data.labels.push(new Date().toLocaleTimeString());
    chart.data.datasets[0].data.push(value);
    if (chart.data.labels.length > 10) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
    }
    chart.update();
}

// Update Process Table
function updateProcessTable(processes) {
    let processTable = document.getElementById('process-table');
    processTable.innerHTML = "";

    processes.forEach(proc => {
        let row = `<tr ${proc.cpu_percent > 50 ? 'style="color:red;"' : ""}>
            <td>${proc.pid}</td>
            <td>${proc.name}</td>
            <td>${proc.cpu_percent.toFixed(2)}%</td>
            <td>${proc.memory_percent.toFixed(2)}%</td>
            <td><button class="kill-btn" onclick="killProcess(${proc.pid})">Kill</button></td>
        </tr>`;
        processTable.innerHTML += row;
    });
}

// Kill Process Function
function killProcess(pid) {
    fetch(`/kill/${pid}`, { method: 'POST' })
        .then(response => response.json())
        .then(data => alert(data.message))
        .catch(error => console.error("Error killing process:", error));
}
