from flask import Flask, jsonify, render_template
import psutil
import os
import signal

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/stats')
def get_stats():
    cpu_usage = psutil.cpu_percent(interval=0.1)  
    memory_usage = psutil.virtual_memory().percent

    processes = []
    for proc in psutil.process_iter(attrs=['pid', 'name', 'cpu_percent', 'memory_percent']):
        try:
            proc_info = proc.info
            if proc_info['name'] == "System Idle Process":
                continue  # Skip idle process

            # Prevent unrealistic CPU values
            if proc_info['cpu_percent'] > 100:
                proc_info['cpu_percent'] = 100

            processes.append(proc_info)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    processes = sorted(processes, key=lambda x: x['cpu_percent'], reverse=True)[:10]

    return jsonify({
        'cpu_usage': cpu_usage,
        'memory_usage': memory_usage,
        'processes': processes
    })



@app.route('/kill/<int:pid>', methods=['POST'])
def kill_process(pid):
    try:
        os.kill(pid, signal.SIGTERM)
        return jsonify({'message': f'Process {pid} terminated successfully.'})
    except Exception as e:
        return jsonify({'message': f'Error terminating process {pid}: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
